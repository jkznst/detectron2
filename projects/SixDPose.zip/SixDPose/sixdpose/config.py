# -*- coding: utf-8 -*-
# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved

from detectron2.config import CfgNode as CN


def add_sixdpose_config(cfg):
    """
    Add config for sixdpose head.
    """
    _C = cfg

    _C.MODEL.PVNET_ON = False

    _C.MODEL.ROI_PVNET_HEAD = CN()
    _C.MODEL.ROI_PVNET_HEAD.NAME = ""
    _C.MODEL.ROI_PVNET_HEAD.NUM_STACKED_CONVS = 8
    _C.MODEL.ROI_PVNET_HEAD.CONV_HEAD_DIM = 512
    # _C.MODEL.ROI_PVNET_HEAD.CONV_HEAD_KERNEL = 3
    _C.MODEL.ROI_PVNET_HEAD.NORM = "BN"
    _C.MODEL.ROI_PVNET_HEAD.CLS_AGNOSTIC_MASK = False
    _C.MODEL.ROI_PVNET_HEAD.NUM_KEYPOINTS = 9
    
    # _C.MODEL.ROI_PVNET_HEAD.DECONV_KERNEL = 4
    # _C.MODEL.ROI_PVNET_HEAD.UP_SCALE = 2
    # _C.MODEL.ROI_PVNET_HEAD.HEATMAP_SIZE = 56
    _C.MODEL.ROI_PVNET_HEAD.POOLER_TYPE = "ROIAlignV2"
    _C.MODEL.ROI_PVNET_HEAD.POOLER_RESOLUTION = 14
    _C.MODEL.ROI_PVNET_HEAD.POOLER_SAMPLING_RATIO = 2
    # # Overlap threshold for an RoI to be considered foreground (if >= FG_IOU_THRESHOLD)
    # _C.MODEL.ROI_PVNET_HEAD.FG_IOU_THRESHOLD = 0.7
    # # Loss weights for annotation masks.(14 Parts)
    # _C.MODEL.ROI_PVNET_HEAD.INDEX_WEIGHTS = 2.0
    # # Loss weights for surface parts. (24 Parts)
    # _C.MODEL.ROI_PVNET_HEAD.PART_WEIGHTS = 0.3
    # # Loss weights for UV regression.
    # _C.MODEL.ROI_PVNET_HEAD.POINT_REGRESSION_WEIGHTS = 0.1

    _C.INPUT.KEYPOINT_FORMAT = 'bb8+fps8'   # 'bb8', 'fps8', 'bb8+fps8'

    # `True` if random blur is used for data augmentation during training
    _C.INPUT.RANDOMBLUR = CN({"ENABLED": True})
    _C.INPUT.RANDOMBLUR.PROB = 0.5

    # `True` if color jitter is used for data augmentation during training
    _C.INPUT.COLORJITTER = CN({"ENABLED": True})
    _C.INPUT.COLORJITTER.BRIGHTNESS = 0.1
    _C.INPUT.COLORJITTER.CONTRAST = 0.1
    _C.INPUT.COLORJITTER.SATURATION = 0.05
    _C.INPUT.COLORJITTER.HUE = 0.05