# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved
from . import dataset  # just to register data
from .config import add_sixdpose_config
from .dataset_mapper import DatasetMapper
from .pvnet_head import ROI_DENSEPOSE_HEAD_REGISTRY
from .coco_evaluator import COCOEvaluator
from .pose_evaluator import SixDPoseEvaluator
from .roi_head import SixDPoseROIHeads
# from .structures import DensePoseDataRelative, DensePoseList, DensePoseTransformData