# -*- coding: utf-8 -*-
# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved

import torch

from detectron2.modeling import ROI_HEADS_REGISTRY, StandardROIHeads
from detectron2.modeling.poolers import ROIPooler
from detectron2.modeling.roi_heads import select_foreground_proposals

from .pvnet_head import (
    build_pvnet_data_filter,
    build_pvnet_head,
    build_pvnet_losses,
    pvnet_inference,
)


@ROI_HEADS_REGISTRY.register()
class PVNetROIHeads(StandardROIHeads):
    """
    A Standard ROIHeads which contains an addition of PVNet head.
    """

    def __init__(self, cfg, input_shape):
        super().__init__(cfg, input_shape)
        self._init_pvnet_head(cfg)

    def _init_pvnet_head(self, cfg):
        # fmt: off
        self.pvnet_on          = cfg.MODEL.PVNET_ON
        if not self.pvnet_on:
            return
        self.pvnet_data_filter = build_pvnet_data_filter(cfg)
        pvnet_pooler_resolution       = cfg.MODEL.ROI_PVNET_HEAD.POOLER_RESOLUTION
        pvnet_pooler_scales           = tuple(1.0 / self.feature_strides[k] for k in self.in_features)
        pvnet_pooler_sampling_ratio   = cfg.MODEL.ROI_PVNET_HEAD.POOLER_SAMPLING_RATIO
        pvnet_pooler_type             = cfg.MODEL.ROI_PVNET_HEAD.POOLER_TYPE
        # fmt: on
        in_channels = [self.feature_channels[f] for f in self.in_features][0]
        self.pvnet_pooler = ROIPooler(
            output_size=pvnet_pooler_resolution,
            scales=pvnet_pooler_scales,
            sampling_ratio=pvnet_pooler_sampling_ratio,
            pooler_type=pvnet_pooler_type,
        )
        self.pvnet_head = build_pvnet_head(cfg, in_channels)
        self.pvnet_predictor = build_pvnet_predictor(
            cfg, self.pvnet_head.n_out_channels
        )
        self.pvnet_losses = build_pvnet_losses(cfg)

    def _forward_pvnet(self, features, instances):
        """
        Forward logic of the pvnet prediction branch.

        Args:
            features (list[Tensor]): #level input features for densepose prediction
            instances (list[Instances]): the per-image instances to train/predict densepose.
                In training, they can be the proposals.
                In inference, they can be the predicted boxes.

        Returns:
            In training, a dict of losses.
            In inference, update `instances` with new fields "densepose" and return it.
        """
        if not self.pvnet_on:
            return {} if self.training else instances

        if self.training:
            proposals, _ = select_foreground_proposals(instances, self.num_classes)
            proposals_pvnet = self.pvnet_data_filter(proposals)
            if len(proposals_pvnet) > 0:
                proposal_boxes = [x.proposal_boxes for x in proposals_pvnet]
                features_pvnet = self.pvnet_pooler(features, proposal_boxes)
                pvnet_head_outputs = self.pvnet_head(features_pvnet)
                pvnet_outputs, _ = self.pvnet_predictor(pvnet_head_outputs)
                pvnet_loss_dict = self.pvnet_losses(proposals_pvnet, pvnet_outputs)
                return pvnet_loss_dict
        else:
            pred_boxes = [x.pred_boxes for x in instances]
            features_pvnet = self.pvnet_pooler(features, pred_boxes)
            if len(features_pvnet) > 0:
                pvnet_head_outputs = self.pvnet_head(features_pvnet)
                pvnet_outputs, _ = self.pvnet_predictor(pvnet_head_outputs)
            else:
                # If no detection occurred instances
                # set pvnet_outputs to empty tensors
                empty_tensor = torch.zeros(size=(0, 0, 0, 0), device=features_pvnet.device)
                pvnet_outputs = tuple([empty_tensor] * 4)

            pvnet_inference(pvnet_outputs, instances)
            return instances

    def forward(self, images, features, proposals, targets=None):
        features_list = [features[f] for f in self.in_features]

        instances, losses = super().forward(images, features, proposals, targets)
        del targets, images

        if self.training:
            losses.update(self._forward_pvnet(features_list, instances))
        else:
            instances = self._forward_pvnet(features_list, instances)
        return instances, losses
